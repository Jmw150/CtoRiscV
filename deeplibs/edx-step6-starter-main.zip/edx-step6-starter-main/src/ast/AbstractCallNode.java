package ast;

public abstract class AbstractCallNode extends ExpressionNode implements StatementNode {

    
}