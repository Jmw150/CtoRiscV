
A "listener" is a program that traverses the parser to perform actions from it.
